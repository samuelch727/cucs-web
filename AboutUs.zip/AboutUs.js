import './AboutUs.css'
import How from './components/How'
import What from './components/What'
import Team from './components/Team'

function AboutUs() {
  return (
    <>
    <div className="AboutUs">
      <div><How /></div>
      <div><What /></div>
      <div><Team /></div>
    </div>
    </>
  );
}

export default AboutUs;
