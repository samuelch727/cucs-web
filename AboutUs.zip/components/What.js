import './What.css';
import '../AboutUs.css';

const What = () => {
    return (
        <div className="What">
            <div className="title">What is OAO?</div>
            <div className="content">OAO, Inspired by emoticons - an interesting usage of words and symbols for reassembling the user's facial expression, coheres to our vision of expediting Mixed Reality. To illustrate, reproducing things into the digital world.<br /><br />
            At OAO, our goal is to make information more accessible. With the idea of Metaverse, we believe developing 3D technology can help to achieve this goal.</div>
        </div>
    )
}

export default What