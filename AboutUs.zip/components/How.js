import './How.css';
import '../AboutUs.css';

const How = () => {
    return (
        <div className="How">
            <div className="title">How Do We Come Togther?</div>
            <div className="content">Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500sLorem Ipsum is simply dummy text of the printing and typesetting industry. 
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500sLorem Ipsum is simply dummy text of the printing and typesetting industry. 
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
            </div>
        </div>
    )
}

export default How

