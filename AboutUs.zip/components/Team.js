import './Team.css';
import '../AboutUs.css';
import banner from './banner.JPEG';
import samuel from './samuel.jpeg';
import ryan from './ryan.jpg';
import 'bootstrap/dist/css/bootstrap.min.css';

const Team = () => {
    return (
        <div className="Team">
            <div className="title">Meet Our Team</div>
            <div className="banner">
                <img align="center" width="1440px" height="473px" src={banner} />   
            </div>

            <div class="container">
                <div class="box">
                    <div class="row">
                        <div class="col">
                            <img class="MemPhoto" src={samuel} />   
                        </div>
                        <div class="col">
                            <img class="MemPhoto" src={samuel} />   
                        </div>
                        <div class="col">
                            <img class="MemPhoto" src={samuel} />   
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">Description</div>
                    <div class="col">Description</div>
                    <div class="col">Description</div>
                </div>
                <div class="box">
                    <div class="row">
                        <div class="col">
                            <img class="MemPhoto" src={ryan} />   
                        </div>
                        <div class="col">
                            <img class="MemPhoto" src={ryan} />   
                        </div>
                        <div class="col">
                            <img class="MemPhoto" src={ryan} />   
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">Description</div>
                    <div class="col">Description</div>
                    <div class="col">Description</div>
                </div>
            </div>  
    </div>

    )
}

export default Team